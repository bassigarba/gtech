// Toggle mobile menu
document.getElementById("menu-btn").addEventListener("click", () => {
  document.getElementById("navbar").classList.toggle("show");
});
